import java.util.Stack;
import java.util.Arrays;
import java.util.EmptyStackException;
import java.util.Scanner;

public class Main {

    static Scanner input = new Scanner(System.in);

    // Example 3: Generic Box
    static class Box<T> {
        private T item;
        public void set(T item) { this.item = item; }
        public T get() { return item; }
    }

    // Example 4: Bank Account
    static class BankAccount {
        private double balance;
        private Stack<Double> history = new Stack<>();

        public BankAccount(double balance) {
            this.balance = balance;
        }

        public void deposit(double amount) {
            balance += amount;
            history.push(amount);
            System.out.println("Deposit " + amount + " -> balance " + balance);
        }

        public void undoLastDeposit() {
            if (history.isEmpty()) {
                System.out.println("Nothing to undo");
                return;
            }
            double last = history.pop();
            balance -= last;
            System.out.println("Undo " + last + " -> balance " + balance);
        }
    }

    // Example 5: Registration
    static class Registration {
        private Stack<String> courses = new Stack<>();

        public void addCourse(String code) {
            courses.push(code);
            System.out.println("Added " + code + " -> " + courses);
        }

        public void undoLastCourse() {
            if (courses.isEmpty()) {
                System.out.println("Nothing to undo");
                return;
            }
            System.out.println("Removed " + courses.pop() + " -> " + courses);
        }
    }

    // Example 6: Reverse String
    static class Reverser {
        public String reverse(String text) {
            Stack<Character> stack = new Stack<>();

            for (int i = 0; i < text.length(); i++) {
                stack.push(text.charAt(i));
            }

            StringBuilder reversed = new StringBuilder();

            while (!stack.isEmpty()) {
                reversed.append(stack.pop());
            }

            return reversed.toString();
        }
    }

    // Example 7: ArrayStack
    static class ArrayStack<T> {
        private static final int DEFAULT_CAPACITY = 2;
        private int top;
        private T[] stack;

        @SuppressWarnings("unchecked")
        public ArrayStack() {
            top = 0;
            stack = (T[]) new Object[DEFAULT_CAPACITY];
        }

        @SuppressWarnings("unchecked")
        public ArrayStack(int capacity) {
            if (capacity <= 0)
                throw new IllegalArgumentException("Invalid capacity");

            top = 0;
            stack = (T[]) new Object[capacity];
        }

        public void push(T element) {
            if (size() == stack.length)
                expandCapacity();

            stack[top] = element;
            top++;
        }

        private void expandCapacity() {
            stack = Arrays.copyOf(stack, stack.length * 2);
        }

        public T pop() {
            if (isEmpty())
                throw new EmptyStackException();

            top--;
            T result = stack[top];
            stack[top] = null;
            return result;
        }

        public T peek() {
            if (isEmpty())
                throw new EmptyStackException();

            return stack[top - 1];
        }

        public int size() {
            return top;
        }

        public boolean isEmpty() {
            return top == 0;
        }

        public int capacity() {
            return stack.length;
        }
    }

    // Example 9: Custom Exception
    static class EmptyCollectionException extends RuntimeException {
        public EmptyCollectionException(String collection) {
            super("The " + collection + " is empty.");
        }
    }

    // Example 10 and 12: Node
    static class Node<T> {
        private T element;
        private Node<T> next;

        public Node() {
            element = null;
            next = null;
        }

        public Node(T element) {
            this.element = element;
            next = null;
        }

        public Node<T> getNext() {
            return next;
        }

        public void setNext(Node<T> next) {
            this.next = next;
        }

        public T getElement() {
            return element;
        }

        public void setElement(T element) {
            this.element = element;
        }
    }

    // Example 12 and 13: LinkedStack
    static class LinkedStack<T> {
        private int count;
        private Node<T> top;

        public LinkedStack() {
            count = 0;
            top = null;
        }

        public void push(T element) {
            Node<T> temp = new Node<>(element);
            temp.setNext(top);
            top = temp;
            count++;
        }

        public T pop() {
            if (isEmpty())
                throw new EmptyStackException();

            T result = top.getElement();
            top = top.getNext();
            count--;

            return result;
        }

        public T peek() {
            if (isEmpty())
                throw new EmptyStackException();

            return top.getElement();
        }

        public boolean isEmpty() {
            return count == 0;
        }

        public int size() {
            return count;
        }
    }

    // Example 1
    static void example1() {
        System.out.println("\nEXAMPLE 1: Push and print a stack");

        Stack<Integer> s1 = new Stack<>();

        s1.push(10);
        s1.push(20);
        s1.push(30);

        System.out.println(s1);
    }

    // Example 2
    static void example2() {
        System.out.println("\nEXAMPLE 2: peek() and pop()");

        Stack<Integer> s1 = new Stack<>();

        s1.push(10);
        s1.push(20);
        s1.push(30);

        System.out.println("Original Stack: " + s1);

        int top = s1.peek();
        System.out.println("top element: " + top);

        System.out.println("Stack after peek: " + s1);

        int out = s1.pop();
        System.out.println("Removed element: " + out);

        System.out.println("Stack after pop: " + s1);
    }

    // Example 3
    static void example3() {
        System.out.println("\nEXAMPLE 3: Generics");

        Box<Integer> box1 = new Box<>();
        box1.set(25);

        Box<String> box2 = new Box<>();
        box2.set("Ali");

        System.out.println("box1 holds " + box1.get());
        System.out.println("box2 holds " + box2.get());
    }

    // Example 4
    static void example4() {
        System.out.println("\nEXAMPLE 4: Bank - Undo Deposit");

        BankAccount acc = new BankAccount(100);

        acc.deposit(50);
        acc.deposit(20);
        acc.deposit(30);

        acc.undoLastDeposit();
        acc.undoLastDeposit();
    }

    // Example 5
    static void example5() {
        System.out.println("\nEXAMPLE 5: Student - Undo Course");

        Registration reg = new Registration();

        reg.addCourse("CA314");
        reg.addCourse("CA301");
        reg.addCourse("MA210");

        reg.undoLastCourse();
    }

    // Example 6
    static void example6() {
        System.out.println("\nEXAMPLE 6: Reverse a String");

        System.out.print("Enter String to Reverse: ");
        String text = input.nextLine();

        Reverser test = new Reverser();

        System.out.println("Reversed String: " + test.reverse(text));
    }

    // Example 7
    static void example7() {
        System.out.println("\nEXAMPLE 7: ArrayStack");

        ArrayStack<Integer> stack = new ArrayStack<>();

        stack.push(10);
        stack.push(20);
        stack.push(30);

        System.out.println("Size: " + stack.size());
        System.out.println("Capacity: " + stack.capacity());
        System.out.println("Peek: " + stack.peek());
        System.out.println("Pop: " + stack.pop());
    }

    // Example 8
    static void example8() {
        System.out.println("\nEXAMPLE 8: ArrayStack Trace");

        ArrayStack<String> s = new ArrayStack<>();

        s.push("A");
        s.push("B");

        System.out.println("size " + s.size()
                + ", capacity " + s.capacity());

        s.push("C");

        System.out.println("size " + s.size()
                + ", capacity " + s.capacity());

        System.out.println("peek: " + s.peek());
        System.out.println("pop: " + s.pop());
        System.out.println("pop: " + s.pop());
        System.out.println("pop: " + s.pop());

        try {
            System.out.println("pop: " + s.pop());
        } catch (EmptyStackException e) {
            System.out.println("Exception: Stack is empty");
        }
    }

    // Example 9
    static void example9() {
        System.out.println("\nEXAMPLE 9: Custom Exception");

        try {
            throw new EmptyCollectionException("stack");
        } catch (EmptyCollectionException e) {
            System.out.println("Caught: " + e.getMessage());
        }
    }

    // Example 10
    static void example10() {
        System.out.println("\nEXAMPLE 10: Linked List Traversal");

        Node<Integer> head = new Node<>(17);
        Node<Integer> n2 = new Node<>(92);
        Node<Integer> n3 = new Node<>(63);
        Node<Integer> n4 = new Node<>(45);

        head.setNext(n2);
        n2.setNext(n3);
        n3.setNext(n4);

        Node<Integer> current = head;

        while (current != null) {
            System.out.println(current.getElement());
            current = current.getNext();
        }
    }

    // Example 11
    static void example11() {
        System.out.println("\nEXAMPLE 11: Insert at the Front");

        Node<String> head = new Node<>("B");
        Node<String> newNode = new Node<>("A");

        newNode.setNext(head);
        head = newNode;

        printChain("Correct: ", head);

        head = new Node<>("B");
        newNode = new Node<>("A");

        head = newNode;
        newNode.setNext(head);

        printChain("Swapped: ", head);
    }

    static void printChain(String label, Node<String> head) {
        System.out.print(label);

        Node<String> cur = head;

        for (int i = 0; i < 5 && cur != null; i++) {
            System.out.print(cur.getElement() + " -> ");
            cur = cur.getNext();
        }

        System.out.println(cur == null ? "null" : "...");
    }

    // Example 12
    static void example12() {
        System.out.println("\nEXAMPLE 12: Node and LinkedStack");

        LinkedStack<Integer> stack = new LinkedStack<>();

        stack.push(10);
        stack.push(20);
        stack.push(30);

        System.out.println("Size: " + stack.size());
        System.out.println("Top: " + stack.peek());
        System.out.println("Removed: " + stack.pop());
        System.out.println("New Top: " + stack.peek());
    }

    // Example 13
    static void example13() {
        System.out.println("\nEXAMPLE 13: LinkedStack Trace");

        LinkedStack<String> s = new LinkedStack<>();

        s.push("A");
        s.push("B");
        s.push("C");

        System.out.println("size: " + s.size());
        System.out.println("peek: " + s.peek());
        System.out.println("pop: " + s.pop());
        System.out.println("size: " + s.size());
        System.out.println("peek: " + s.peek());
    }

    // Example 14
    static void example14() {
        System.out.println("\nEXAMPLE 14: Bank with LinkedStack");

        LinkedStack<Double> history = new LinkedStack<>();

        double balance = 100;

        balance += 50;
        history.push(50.0);
        System.out.println("Deposit 50.0 -> balance " + balance);

        balance += 20;
        history.push(20.0);
        System.out.println("Deposit 20.0 -> balance " + balance);

        balance += 30;
        history.push(30.0);
        System.out.println("Deposit 30.0 -> balance " + balance);

        double last = history.pop();
        balance -= last;
        System.out.println("Undo " + last + " -> balance " + balance);

        last = history.pop();
        balance -= last;
        System.out.println("Undo " + last + " -> balance " + balance);
    }

    // Example 15
    static void example15() {
        System.out.println("\nEXAMPLE 15: Student with LinkedStack");

        LinkedStack<String> courses = new LinkedStack<>();

        addCourse(courses, "CA314");
        addCourse(courses, "CA301");
        addCourse(courses, "MA210");

        undoCourse(courses);
        undoCourse(courses);
    }

    static void addCourse(LinkedStack<String> courses, String code) {
        courses.push(code);

        System.out.println("Added " + code
                + " | top: " + courses.peek()
                + " | size: " + courses.size());
    }

    static void undoCourse(LinkedStack<String> courses) {
        if (courses.isEmpty()) {
            System.out.println("Nothing to undo");
            return;
        }

        String removed = courses.pop();

        System.out.println("Removed " + removed
                + " | size: " + courses.size());
    }

    // Main Menu
    public static void main(String[] args) {

        while (true) {

            System.out.println("\n==================================");
            System.out.println("     STACKS IN JAVA - ALL EXAMPLES");
            System.out.println("==================================");

            System.out.println("1. Push and print a stack");
            System.out.println("2. peek() and pop()");
            System.out.println("3. Generics");
            System.out.println("4. Bank: Undo Deposit");
            System.out.println("5. Student: Undo Course");
            System.out.println("6. Reverse a String");
            System.out.println("7. ArrayStack");
            System.out.println("8. ArrayStack Trace");
            System.out.println("9. Custom Exception");
            System.out.println("10. Linked List Traversal");
            System.out.println("11. Insert at the Front");
            System.out.println("12. Node and LinkedStack");
            System.out.println("13. LinkedStack Trace");
            System.out.println("14. Bank with LinkedStack");
            System.out.println("15. Student with LinkedStack");
            System.out.println("0. Exit");

            System.out.println("----------------------------------");
            System.out.print("Choose example (0-15): ");

            String choice = input.nextLine();

            switch (choice) {

                case "1": example1(); break;
                case "2": example2(); break;
                case "3": example3(); break;
                case "4": example4(); break;
                case "5": example5(); break;
                case "6": example6(); break;
                case "7": example7(); break;
                case "8": example8(); break;
                case "9": example9(); break;
                case "10": example10(); break;
                case "11": example11(); break;
                case "12": example12(); break;
                case "13": example13(); break;
                case "14": example14(); break;
                case "15": example15(); break;

                case "0":
                    System.out.println("Program closed. Goodbye!");
                    input.close();
                    return;

                default:
                    System.out.println("Invalid choice. Try again.");
            }

            System.out.println("\nPress Enter to continue...");
            input.nextLine();
        }
    }
}